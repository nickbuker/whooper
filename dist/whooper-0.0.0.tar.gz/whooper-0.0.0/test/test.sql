select
    col1
    col2
from
    pretend.first_table
limit
    1000;